// for execute butto
API.Execute();

// for checking roblox add along with inject and execute
API.IsRobloxOpen();

// for inject button
API.Inject();