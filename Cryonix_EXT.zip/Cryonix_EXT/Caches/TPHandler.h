#pragma once
#include "../globals.h"
#include <thread>
#include <vector>

inline void TPHandler() {
    while (true) {
        uintptr_t base = Memory->getBaseAddress();
        if (!base) { std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }
        uintptr_t fakeDataModel = Memory->read<uintptr_t>(base + offsets::FakeDataModelPointer);
        if (!fakeDataModel) { std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }

        RobloxInstance dataModel(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));
        if (!dataModel || !dataModel.address) { std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }

        int placeId = Memory->read<int>(dataModel.address + offsets::PlaceId);
        if (dataModel.Name() == "LuaApp" || placeId != Globals::Roblox::lastPlaceID) {
            log("Teleport detected, reinitializing DataModel...", 3);
            do {
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                fakeDataModel = Memory->read<uintptr_t>(base + offsets::FakeDataModelPointer);
                dataModel = RobloxInstance(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));
            } while (!dataModel || dataModel.Name() != "Ugc");
            Globals::Roblox::DataModel = dataModel;
            uintptr_t visualEngine = 0;
            while (!(visualEngine = Memory->read<uintptr_t>(base + offsets::VisualEnginePointer))) {
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
            }

            Globals::Roblox::VisualEngine = visualEngine;
            Globals::Roblox::Workspace = dataModel.FindFirstChildWhichIsA("Workspace");
            Globals::Roblox::Players = dataModel.FindFirstChildWhichIsA("Players");
            Globals::Roblox::Camera = Globals::Roblox::Workspace.FindFirstChildWhichIsA("Camera");
            Globals::Roblox::LocalPlayer = RobloxInstance(Memory->read<uintptr_t>(Globals::Roblox::Players.address + offsets::LocalPlayer));
            Globals::Roblox::lastPlaceID = placeId;
            Globals::Caches::CachedPlayers.clear();
            Globals::Caches::CachedPlayerObjects.clear();
            log("DataModel reinitialized successfully.", 1);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}