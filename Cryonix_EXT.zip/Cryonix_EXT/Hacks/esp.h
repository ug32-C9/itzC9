#pragma once
#include "../renderer/W2S.h"
#include "../renderer/imgui/imgui.h"
#include "../options.h"
#include <algorithm>

inline void RenderESP(ImDrawList* drawList) {
    auto localTeam = Globals::Roblox::LocalPlayer.Team();
    auto cameraPos = Memory->read<Vectors::Vector3>(Globals::Roblox::Camera.address + offsets::CameraPos);
    auto localCharacter = Globals::Roblox::LocalPlayer.Character();
    auto localHead = localCharacter.FindFirstChild("Head");
    auto localTorso = localCharacter.FindFirstChild("Torso");
    if (localTorso.address == 0) localTorso = localCharacter.FindFirstChild("UpperTorso");
    auto localHeadPos = localHead.Position();
    auto localTorsoPos = localTorso.Position();
    auto localTorsoPos2D = WorldToScreen(localTorsoPos);
    auto Dimensions = Memory->read<Vectors::Vector2>(Globals::Roblox::VisualEngine + offsets::Dimensions);
    ImFont* font = ImGui::GetFont();
    if (Globals::Caches::CachedPlayerObjects.empty()) return;

    for (auto& player : Globals::Caches::CachedPlayerObjects) {
        if (player.address == Globals::Roblox::LocalPlayer.address || player.Health <= 0) continue;
        if (player.Team.address == localTeam.address && Options::ESP::TeamCheck) continue;
        auto head = player.Head;
        if (head.Transparency() >= 1.f && Options::ESP::TransparencyCheck) continue;

        RobloxInstance torso(0), rLeg(0), lLeg(0), rArm(0), lArm(0);
        if (player.RigType == 0) {
            torso = player.Torso; rLeg = player.Right_Leg; lLeg = player.Left_Leg; rArm = player.Right_Arm; lArm = player.Left_Arm;
        } else {
            torso = player.Upper_Torso; rLeg = player.Right_Foot; lLeg = player.Left_Foot; rArm = player.Right_Hand; lArm = player.Left_Hand;
        }

        auto head3D = head.Position(), torso3D = torso.Position(), rLeg3D = rLeg.Position(), lLeg3D = lLeg.Position(), rArm3D = rArm.Position(), lArm3D = lArm.Position();
        auto head2D = WorldToScreen(head3D), torso2D = WorldToScreen(torso3D);
        if (torso2D.x == -1) continue;

        float distance = (localHeadPos - head3D).Magnitude();
        float camDistance = (cameraPos - head3D).Magnitude();
        float scale = std::clamp(1.f / camDistance * 20.f, 0.8f, 2.f);

        auto newHeadPos = WorldToScreen(head3D + Vectors::Vector3{0.f, 0.8f, 0.f});
        auto newHeadName = WorldToScreen(head3D + Vectors::Vector3{0.f, 2.2f, 0.f});
        auto newLeftLeg = WorldToScreen(lLeg3D - Vectors::Vector3{0.f, 1.f, 0.f});
        auto hrpCFrame = player.HumanoidRootPart.CFrame();
        Vectors::Vector3 rightVec = hrpCFrame.GetRightVector();
        Vectors::Vector3 leftWorld = torso3D - (rightVec * 2.f);
        Vectors::Vector3 rightWorld = torso3D + (rightVec * 2.f);
        auto left2D = WorldToScreen(leftWorld);
        auto right2D = WorldToScreen(rightWorld);
        ImVec2 topLeft(std::min(left2D.x, right2D.x), newHeadPos.y);
        ImVec2 bottomRight(std::max(left2D.x, right2D.x), newLeftLeg.y);
        int roundedDist = static_cast<int>(std::round(distance));

        ImColor boxColor = IM_COL32(Options::ESP::BoxColor[0]*255, Options::ESP::BoxColor[1]*255, Options::ESP::BoxColor[2]*255, 255);
        ImColor fillColor = IM_COL32(Options::ESP::BoxFillColor[0]*255, Options::ESP::BoxFillColor[1]*255, Options::ESP::BoxFillColor[2]*255, Options::ESP::BoxFillColor[3]*255);
        ImColor distColor = IM_COL32(Options::ESP::DistanceColor[0]*255, Options::ESP::DistanceColor[1]*255, Options::ESP::DistanceColor[2]*255, 255);
        ImColor tracerColor = IM_COL32(Options::ESP::TracerColor[0]*255, Options::ESP::TracerColor[1]*255, Options::ESP::TracerColor[2]*255, 255);
        ImColor skeletonColor = IM_COL32(Options::ESP::SkeletonColor[0]*255, Options::ESP::SkeletonColor[1]*255, Options::ESP::SkeletonColor[2]*255, 255);
        ImColor color = IM_COL32(Options::ESP::Color[0]*255, Options::ESP::Color[1]*255, Options::ESP::Color[2]*255, 255);

        if (Options::ESP::Box) {
            if (topLeft.x < bottomRight.x && topLeft.y < bottomRight.y) {
                if (!Options::ESP::RemoveBorders)
                    drawList->AddRect(topLeft, bottomRight, IM_COL32(0,0,0,255), 0, 0, 3.5f);
                drawList->AddRect(topLeft, bottomRight, boxColor, 0, 0, 2.f);
                drawList->AddRectFilled(topLeft, bottomRight, fillColor);
            }
        }

        if (Options::ESP::Tracers) {
            float tThick = Options::ESP::TracerThickness, oThick = tThick + 1.5f;
            ImVec2 start;
            switch (Options::ESP::TracersStart) {
                case 0: start = ImVec2(Dimensions.x/2, Dimensions.y); break;
                case 1: start = ImVec2(Dimensions.x/2, 0); break;
                case 2: { POINT p; GetCursorPos(&p); start = ImVec2(p.x,p.y); } break;
                case 3: start = localTorsoPos2D; break;
            }
            if (!Options::ESP::RemoveBorders) drawList->AddLine(start, head2D, IM_COL32(0,0,0,255), oThick);
            drawList->AddLine(start, head2D, tracerColor, tThick);
        }

        if (Options::ESP::Skeleton) {
            auto lShoulder = WorldToScreen(torso3D + Vectors::Vector3{-1.f,0.5f,0.f});
            auto rShoulder = WorldToScreen(torso3D + Vectors::Vector3{1.f,0.5f,0.f});
            auto hipCenter = WorldToScreen(torso3D + Vectors::Vector3{0.f,-0.5f,0.f});
            auto lHand = WorldToScreen(lArm3D + Vectors::Vector3{-0.5f,0.f,0.f});
            auto rHand = WorldToScreen(rArm3D + Vectors::Vector3{0.5f,0.f,0.f});
            auto lFoot = WorldToScreen(lLeg3D + Vectors::Vector3{-0.3f,-0.5f,0.f});
            auto rFoot = WorldToScreen(rLeg3D + Vectors::Vector3{0.3f,-0.5f,0.f});
            auto line = [&](ImVec2 a, ImVec2 b){ if(!Options::ESP::RemoveBorders) drawList->AddLine(a,b,IM_COL32(0,0,0,255),3.5f); drawList->AddLine(a,b,skeletonColor,2.f); };
            line(head2D, torso2D); line(lShoulder, lArm2D); line(lArm2D, lHand); line(rShoulder, rArm2D); line(rArm2D, rHand);
            line(hipCenter, lLeg2D); line(lLeg2D, lFoot); line(hipCenter, rLeg2D); line(rLeg2D, rFoot); line(torso2D, hipCenter); line(lShoulder, rShoulder);
        }

        if (Options::ESP::Name) {
            ImVec2 size = font->CalcTextSizeA(12.f*scale, FLT_MAX, 0.f, player.Name.c_str());
            drawList->AddText(font, 12.f*scale, ImVec2(newHeadName.x - size.x/2, newHeadName.y), color, player.Name.c_str());
        }

        if (Options::ESP::Distance) {
            std::string dist = std::to_string(roundedDist) + " studs";
            ImVec2 size = font->CalcTextSizeA(8.f*scale, FLT_MAX, 0.f, dist.c_str());
            drawList->AddText(font, 8.f*scale, ImVec2(head2D.x - size.x/2, newLeftLeg.y), distColor, dist.c_str());
        }

        if (Options::ESP::Health) {
            float hp = std::clamp(player.Health / player.MaxHealth, 0.f, 1.f);
            float barW = std::clamp(scale*4.f,2.f,6.f);
            float h = bottomRight.y - topLeft.y;
            ImVec2 tL(topLeft.x - barW - 2, topLeft.y), bR(topLeft.x - 2, topLeft.y + h);
            drawList->AddRectFilled(tL,bR,IM_COL32(50,50,50,180));
            ImVec2 fTL(tL.x,bR.y - h*hp), fBR(bR.x,bR.y);
            drawList->AddRectFilled(fTL,fBR,IM_COL32(0,255,0,220));
            drawList->AddRect(tL,bR,IM_COL32(0,0,0,255));
        }
    }
}