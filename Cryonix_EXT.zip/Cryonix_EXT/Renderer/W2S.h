#pragma once
#include "../Utils/structures.h"
#include "../Offsets/offsets.h"
#include "../globals.h"
#include "imgui/imgui.h"

inline Vectors::Vector2 WorldToScreen(const Vectors::Vector3& world) {
    const auto viewmatrix = Memory->read<Matrixes::Matrix4>(Globals::Roblox::VisualEngine + offsets::viewmatrix);
    
    Vectors::Vector4 quaternion;
    quaternion.x = (world.x * viewmatrix.data[0]) + (world.y * viewmatrix.data[1]) + (world.z * viewmatrix.data[2]) + viewmatrix.data[3];
    quaternion.y = (world.x * viewmatrix.data[4]) + (world.y * viewmatrix.data[5]) + (world.z * viewmatrix.data[6]) + viewmatrix.data[7];
    quaternion.z = (world.x * viewmatrix.data[8]) + (world.y * viewmatrix.data[9]) + (world.z * viewmatrix.data[10]) + viewmatrix.data[11];
    quaternion.w = (world.x * viewmatrix.data[12]) + (world.y * viewmatrix.data[13]) + (world.z * viewmatrix.data[14]) + viewmatrix.data[15];

if (quaternion.w < 0.1f)
    return { -1.0f, -1.0f };

const float inv_w = 1.0f / quaternion.w;
const Vectors::Vector3 ndc = {
    quaternion.x * inv_w,
    quaternion.y * inv_w,
    quaternion.z * inv_w
};

HWND hwnd = FindWindowA(nullptr, "Roblox");
    if (!hwnd)
        return { -1.0f, -1.0f };
RECT clientRect{};
if (!GetClientRect(hwnd, &clientRect))
    return { -1.0f, -1.0f };
POINT point{ 0, 0 };
ClientToScreen(hwnd, &point);
const float width = static_cast<float>(clientRect.right);
const float height = static_cast<float>(clientRect.bottom);
return {
    ((width / 2.0f) * ndc.x + (width / 2.0f)) + static_cast<float>(point.x),
    (-(height / 2.0f) * ndc.y + (height / 2.0f)) + static_cast<float>(point.y)
    };
}