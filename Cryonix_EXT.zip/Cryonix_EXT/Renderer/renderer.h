#pragma once

#pragma comment (lib, "d3d11.lib")
#pragma comment(lib, "dwmapi.lib")

#include <dwmapi.h>
#include <Windows.h>
#include <d3d11.h>
#include <tchar.h>
#include <algorithm>
#include <string>
#include <thread>
#include <iostream>
#include <filesystem>
#include "imgui/imgui.h"
#include "imgui/imgui_impl_win32.h"
#include "imgui/imgui_impl_dx11.h"
#include "imgui/KeyBind.h"
#include "imgui/imgui_settings.h"
#include "font/IconsFontAwesome6.h"
#include "../globals.h"
#include "../options.h"
#include "../Utils/configs.h"
#include "../Hacks/esp.h"
#include "../Hacks/aimbot.h"
#include "W2S.h"

static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static bool g_SwapChainOccluded = false;
static UINT g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

bool IsGameOnTop(const std::string& expectedTitle) {
    HWND hwnd = GetForegroundWindow();
    if (!hwnd) return false;
    char windowTitle[256];
    int length = GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle));
    if (length == 0) return false;
    return expectedTitle == std::string(windowTitle);
}

void SetTransparency(HWND hwnd, bool boolean) {
    LONG exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
    if (boolean) {
        exStyle |= WS_EX_TRANSPARENT;
        SetWindowLong(hwnd, GWL_EXSTYLE, exStyle);
    } else {
        exStyle &= ~WS_EX_TRANSPARENT;
        SetWindowLong(hwnd, GWL_EXSTYLE, exStyle);
    }
}

void DrawNode(RobloxInstance& node) {
    const auto& children = node.GetChildren();
    if (children.empty()) {
        ImGui::BulletText(node.Name().c_str());
    } else {
        if (ImGui::TreeNode(node.Name().c_str())) {
            for (auto child : children) {
                DrawNode(child);
            }
            ImGui::TreePop();
        }
    }
}

void ShowImgui() {
    ImGui_ImplWin32_EnableDpiAwareness();
    float main_scale = ImGui_ImplWin32_GetDpiScaleForMonitor(::MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY));
    size_t width = GetSystemMetrics(SM_CXSCREEN), height = GetSystemMetrics(SM_CYSCREEN);

    WNDCLASSEXW wc{ sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr),
                    nullptr, nullptr, nullptr, nullptr, L"ImGui Example", nullptr };
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowExW(WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW, wc.lpszClassName, L"CryonixV2",
                                  WS_POPUP, 0, 0, width + 1, height + 1, nullptr, nullptr, wc.hInstance, nullptr);
    SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 255, LWA_ALPHA);
    MARGINS margin{ -1 }; DwmExtendFrameIntoClientArea(hwnd, &margin);

    if (!CreateDeviceD3D(hwnd)) { CleanupDeviceD3D(); ::UnregisterClassW(wc.lpszClassName, wc.hInstance); }
    ::ShowWindow(hwnd, SW_SHOWDEFAULT); ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION(); ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();

    auto setColor = [&](ImGuiCol idx, ImVec4 c){ style.Colors[idx] = c; };
    setColor(ImGuiCol_Text, {1,1,1,1}); setColor(ImGuiCol_TextDisabled, {0.32f,0.31f,0.41f,1});
    setColor(ImGuiCol_WindowBg, {0.08f,0.12f,0.18f,0.86f}); setColor(ImGuiCol_ChildBg, {0.10f,0.14f,0.20f,0});
    setColor(ImGuiCol_PopupBg, {0.08f,0.12f,0.18f,0.86f}); setColor(ImGuiCol_Border, {0.39f,0.58f,0.93f,0.78f});
    setColor(ImGuiCol_BorderShadow, {0,0,0,0}); setColor(ImGuiCol_FrameBg, {0.12f,0.16f,0.22f,1});
    setColor(ImGuiCol_FrameBgHovered, {0.16f,0.20f,0.28f,1}); setColor(ImGuiCol_FrameBgActive, {0.20f,0.24f,0.32f,1});
    setColor(ImGuiCol_TitleBg, {0.08f,0.12f,0.18f,1}); setColor(ImGuiCol_TitleBgActive, {0.12f,0.18f,0.26f,1});
    setColor(ImGuiCol_MenuBarBg, {0.08f,0.12f,0.18f,1}); setColor(ImGuiCol_ScrollbarGrab, {0.39f,0.58f,0.93f,1});
    setColor(ImGuiCol_ScrollbarGrabHovered, {0.47f,0.66f,1,1}); setColor(ImGuiCol_CheckMark, {0.68f,0.85f,0.90f,1});
    setColor(ImGuiCol_Button, {0.12f,0.16f,0.22f,1}); setColor(ImGuiCol_ButtonHovered, {0.16f,0.22f,0.30f,1});
    setColor(ImGuiCol_ButtonActive, {0.20f,0.28f,0.38f,1}); setColor(ImGuiCol_HeaderHovered, {0.16f,0.22f,0.30f,1});
    setColor(ImGuiCol_Separator, {0.39f,0.58f,0.93f,0.78f}); setColor(ImGuiCol_TabHovered, {0.39f,0.58f,0.93f,0.80f});
    setColor(ImGuiCol_TabActive, {0.39f,0.58f,0.93f,1}); setColor(ImGuiCol_TabUnfocusedActive, {0.16f,0.22f,0.30f,1});

    style.WindowPadding = {15,15}; style.FramePadding = {8,4}; style.ItemSpacing = {8,8};
    style.ScrollbarSize = 8.0f; style.GrabMinSize = 20; style.WindowRounding = 6.0f;
    style.ChildRounding = 8.0f; style.FrameRounding = 4.0f; style.TabRounding = 4.0f;

    ImFontConfig cfg; cfg.MergeMode = false; cfg.PixelSnapH = true;
    ImFont* baseFont = io.Fonts->AddFontDefault(&cfg); cfg.MergeMode = true;
    static const ImWchar icons[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    io.Fonts->AddFontFromFileTTF("fonts/fa-regular-400.ttf", 10.0f, &cfg, icons);
    io.Fonts->AddFontFromFileTTF("fonts/fa-solid-900.ttf", 10.0f, &cfg, icons);
    io.Fonts->AddFontFromFileTTF("fonts/fa-brands-400.ttf", 10.0f, &cfg, icons);

    ImGui_ImplWin32_Init(hwnd); ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);
    ImGui_ImplDX11_CreateDeviceObjects();

    ImVec4 clear_color{0,0,0,0}; bool done = false;
    static bool showMenu = true, playerList = false, explorer = false; static std::string spectatingSubject;

    while (!done) {
        MSG msg; while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) { ::TranslateMessage(&msg); ::DispatchMessage(&msg); if (msg.message == WM_QUIT) done = true; }
        if (done) break;

        if (g_SwapChainOccluded && g_pSwapChain->Present(0, 0) == DXGI_STATUS_OCCLUDED) { ::Sleep(10); continue; }
        g_SwapChainOccluded = false;
        if (g_ResizeWidth && g_ResizeHeight) { CleanupRenderTarget(); g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0); g_ResizeWidth = g_ResizeHeight = 0; CreateRenderTarget(); }

        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        if (GetAsyncKeyState(VK_INSERT) & 1) { SetTransparency(hwnd, showMenu); showMenu = !showMenu; }

        static int category = 0;
        ImGui::SetNextWindowSize({660,740});
        auto character = Globals::Roblox::LocalPlayer.Character();

        if (showMenu) {
            ImGui::Begin("CRYONIX", nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoTitleBar);
            ImVec2 winPos = ImGui::GetWindowPos(), winSize = ImGui::GetWindowSize();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->AddRectFilled({winPos.x,winPos.y},{winPos.x+winSize.x,winPos.y+60},IM_COL32(28,29,32,220));

            ImGui::SetCursorPos({winSize.x-80,20}); ImGui::TextColored({1,1,1,1},"CRYONIX");
            ImGui::SetCursorPos({20,20});
            if (ImGui::Button(ICON_FA_EYE "##general",{30,30})) category = 0; ImGui::SameLine();
            if (ImGui::Button(ICON_FA_CROSSHAIRS "##aimbot",{30,30})) category = 1; ImGui::SameLine();
            if (ImGui::Button(ICON_FA_WRENCH "##misc",{30,30})) category = 2; ImGui::SameLine();
            if (ImGui::Button(ICON_FA_USERS "##players",{30,30})) playerList = !playerList;

            ImGui::SetCursorPosY(80);
            ImGui::BeginChild("##sidebar",{200,winSize.y-100},true);
            ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign,{0,0.5f}); ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,{15,10});
            if (ImGui::Button(ICON_FA_EYE " GENERAL",{-1,40})) category = 0;
            if (ImGui::Button(ICON_FA_CROSSHAIRS " AIMBOT",{-1,40})) category = 1;
            if (ImGui::Button(ICON_FA_WRENCH " MISC",{-1,40})) category = 2;
            ImGui::Separator();
            if (ImGui::Button(ICON_FA_PALETTE " OTHERS",{-1,40})) category = 3;
            if (ImGui::Button(ICON_FA_KEYBOARD " Keybind",{-1,40})) { /* keybind functionality */ }
            ImGui::PopStyleVar(2);
            ImGui::EndChild();

            ImGui::SameLine(); ImGui::BeginChild("##content",{0,0},true);
            switch (category) {
                case 0: ImGui::Text("ESP Settings"); ImGui::Checkbox("Team Check",&Options::ESP::TeamCheck); break;
                case 1: ImGui::Text("Aimbot Settings"); ImGui::Checkbox("Aimbot",&Options::Aimbot::Aimbot); break;
                case 2: ImGui::Text("Misc Settings"); ImGui::SliderFloat("Walkspeed",&Options::Misc::Walkspeed,0.f,500.f,"%.0f"); break;
                case 3: ImGui::Text("Other Settings"); break;
            }
            ImGui::EndChild(); ImGui::End();
        }

        if (IsGameOnTop("Roblox")) {
            auto ds = io.DisplaySize; std::string str = "Cryonix | " + std::to_string((int)io.Framerate) + " FPS";
            ImVec2 pos{ds.x - ImGui::CalcTextSize(str.c_str()).x - 10,10}; auto* dl = ImGui::GetBackgroundDrawList();
            dl->AddText({pos.x-1,pos.y-1},IM_COL32(0,0,0,255),str.c_str());
            dl->AddText(pos,IM_COL32(0,150,255,255),str.c_str());
        }

        ImGui::Render();
        const float clr[4]={clear_color.x*clear_color.w,clear_color.y*clear_color.w,clear_color.z*clear_color.w,clear_color.w};
        g_pd3dDeviceContext->OMSetRenderTargets(1,&g_mainRenderTargetView,nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView,clr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        HRESULT hr = g_pSwapChain->Present(0,0); g_SwapChainOccluded = (hr==DXGI_STATUS_OCCLUDED);
    }

    ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    CleanupDeviceD3D(); ::DestroyWindow(hwnd); ::UnregisterClassW(wc.lpszClassName,wc.hInstance);
}

bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 4;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    HRESULT res = D3D11CreateDeviceAndSwapChain(
        nullptr,
        D3D_DRIVER_TYPE_HARDWARE,
        nullptr,
        createDeviceFlags,
        featureLevelArray,
        2,
        D3D11_SDK_VERSION,
        &sd,
        &g_pSwapChain,
        &g_pd3dDevice,
        &featureLevel,
        &g_pd3dDeviceContext
    );

    if (res == DXGI_ERROR_UNSUPPORTED)
        res = D3D11CreateDeviceAndSwapChain(
            nullptr,
            D3D_DRIVER_TYPE_WARP,
            nullptr,
            createDeviceFlags,
            featureLevelArray,
            2,
            D3D11_SDK_VERSION,
            &sd,
            &g_pSwapChain,
            &g_pd3dDevice,
            &featureLevel,
            &g_pd3dDeviceContext
        );

    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget() {
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget() {
    if (g_mainRenderTargetView) {
        g_mainRenderTargetView->Release();
        g_mainRenderTargetView = nullptr;
    }
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam);
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}