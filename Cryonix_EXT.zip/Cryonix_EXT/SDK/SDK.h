#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <iostream>

#include "../Offsets/offsets.h"
#include "../Utils/structures.h"
#include "../Memory/MemoryManager.h"

class RobloxInstance {
public:
    uintptr_t address;

    explicit RobloxInstance(uintptr_t addy = 0) : address(addy) {}

    operator bool() const { return address != 0; }

    inline std::string Name() const {
        return Memory->readString(Memory->read<uintptr_t>(address + offsets::Name));
    }

    inline std::string Class() const {
        auto classDesc = Memory->read<uintptr_t>(address + offsets::ClassDescriptor);
        return Memory->readString(Memory->read<uintptr_t>(classDesc + offsets::ClassDescriptorToClassName));
    }

    inline bool IsA(const std::string& className) const {
        return Class() == className;
    }

    inline std::vector<RobloxInstance> GetChildren() const {
        uintptr_t childrenStart = Memory->read<uintptr_t>(address + offsets::Children);
        uintptr_t childrenEnd = Memory->read<uintptr_t>(childrenStart + offsets::ChildrenEnd);

        std::vector<RobloxInstance> children;
        for (uintptr_t child = Memory->read<uintptr_t>(childrenStart); child < childrenEnd; child += 0x10)
            children.emplace_back(Memory->read<uintptr_t>(child));

        return children;
    }

    inline RobloxInstance FindFirstChild(const std::string& name = "") const {
        for (const auto& child : GetChildren()) {
            if (name.empty() || child.Name() == name)
                return child;
        }
        return {};
    }

    inline RobloxInstance FindFirstChildWhichIsA(const std::string& className = "") const {
        for (const auto& child : GetChildren()) {
            if (child.Class() == className)
                return child;
        }
        return {};
    }

    inline Vectors::Vector3 Position() const {
        return Memory->read<Vectors::Vector3>(Memory->read<uintptr_t>(address + offsets::Primitive) + offsets::Position);
    }

    inline float Transparency() const {
        return Memory->read<float>(address + offsets::Transparency);
    }

    inline Vectors::Vector3 Size() const {
        return Memory->read<Vectors::Vector3>(Memory->read<uintptr_t>(address + offsets::Primitive) + offsets::PartSize);
    }

    inline sCFrame CFrame() const {
        if (Class() == "Camera") {
            auto rotation = Memory->read<Matrixes::Matrix3x3>(address + offsets::CameraRotation);
            auto position = Memory->read<Vectors::Vector3>(address + offsets::CameraPos);
            return { rotation.r00, rotation.r01, rotation.r02,
                     rotation.r10, rotation.r11, rotation.r12,
                     rotation.r20, rotation.r21, rotation.r22,
                     position.x, position.y, position.z };
        }

        uintptr_t primitiveAddr = Memory->read<uintptr_t>(address + offsets::Primitive);
        auto rotation = Memory->read<Matrixes::Matrix3x3>(primitiveAddr + offsets::Rotation);
        auto position = Memory->read<Vectors::Vector3>(primitiveAddr + offsets::Position);

        return { rotation.r00, rotation.r01, rotation.r02,
                 rotation.r10, rotation.r11, rotation.r12,
                 rotation.r20, rotation.r21, rotation.r22,
                 position.x, position.y, position.z };
    }

    inline RobloxInstance Character() const {
        return RobloxInstance(Memory->read<uintptr_t>(address + offsets::ModelInstance));
    }

    inline float Health() const {
        auto humanoid = Character().FindFirstChildWhichIsA("Humanoid");
        return Memory->read<float>(humanoid.address + offsets::Health);
    }

    inline float MaxHealth() const {
        auto humanoid = Character().FindFirstChildWhichIsA("Humanoid");
        return Memory->read<float>(humanoid.address + offsets::MaxHealth);
    }

    inline RobloxInstance Team() const {
        return RobloxInstance(Memory->read<uintptr_t>(address + offsets::Team));
    }

    inline int RigType() const {
        return Memory->read<int>(address + offsets::RigType);
    }

    inline void SetWalkspeed(float value) {
        value = std::round(value);
        Memory->write(address + offsets::WalkSpeedCheck, value);
        Memory->write(address + offsets::WalkSpeed, value);
    }

    inline void SetJumpPower(float value) {
        value = std::round(value);
        Memory->write(address + offsets::JumpPower, value);
    }

    inline float GetWalkspeed() const {
        return std::round(Memory->read<float>(address + offsets::WalkSpeed));
    }

    inline float GetJumpPower() const {
        return std::round(Memory->read<float>(address + offsets::JumpPower));
    }

    inline float GetFOV() const {
        auto radians = Memory->read<float>(address + offsets::FOV);
        return std::round(radians * 180.0f / 3.1415926535f);
    }

    inline void SetFOV(float value) const {
        auto radians = std::round(value) * 3.1415926535f / 180.0f;
        Memory->write<float>(address + offsets::FOV, radians);
    }
};