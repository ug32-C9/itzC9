#pragma once

// Text color
#define RESET         "\033[0m"
#define PURPLE        "\033[35m"
#define MAGENTA       "\033[95m"
#define RED           "\033[31m"
#define BLUE          "\033[34m"

// Custom Cryonix color palette
#define CRYONIX_BLUE      "\033[38;2;100;149;237m"   // Cornflower blue
#define CRYONIX_PURPLE    "\033[38;2;147;112;219m"   // Medium slate blue
#define CRYONIX_MAGENTA   "\033[38;2;255;0;255m"     // Vibrant magenta
#define CRYONIX_RED       "\033[38;2;220;20;60m"     // Crimson red
#define CRYONIX_DEEP_BLUE "\033[38;2;0;0;139m"       // Dark blue

// Styles
#define BOLD        "\033[1m"
#define DIM         "\033[2m"
#define UNDERLINE   "\033[4m"
#define BLINK       "\033[5m"
#define REVERSE     "\033[7m"
#define HIDDEN      "\033[8m"

// Background color
#define BG_PURPLE   "\033[45m"
#define BG_MAGENTA  "\033[105m"
#define BG_RED      "\033[41m"
#define BG_BLUE     "\033[44m"

// Bright backgrounds
#define BG_BRIGHT_PURPLE   "\033[105m"
#define BG_BRIGHT_MAGENTA  "\033[105m"
#define BG_BRIGHT_RED      "\033[101m"
#define BG_BRIGHT_BLUE     "\033[104m"