#pragma once
#include <string>
#include <iostream>
#include <thread>
#include <sstream>
#include <iomanip>
#include <windows.h>
#include "colors.h"

void print_line(const std::string& line, int time) {
    for (char c : line)
    {
        std::cout << c << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(time));
    }
    std::cout << std::endl;
}

void log(const std::string& line, int type) {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    SetConsoleMode(hOut, dwMode);

    switch (type)
    {
    case 0:
        print_line(std::string(CRYONIX_PURPLE) + "[" + CRYONIX_MAGENTA + "*" + CRYONIX_PURPLE + "]" + CRYONIX_BLUE + " " + line, 0);
        break;
    case 1:
        print_line(std::string(CRYONIX_PURPLE) + "[" + CRYONIX_BLUE + "+" + CRYONIX_PURPLE + "]" + CRYONIX_MAGENTA + " " + line, 0);
        break;
    case 2:
        print_line(std::string(CRYONIX_PURPLE) + "[" + CRYONIX_RED + "-" + CRYONIX_PURPLE + "]" + CRYONIX_BLUE + " " + line, 0);
        break;
    case 3:
        print_line(std::string(CRYONIX_PURPLE) + "[" + CRYONIX_MAGENTA + ">" + CRYONIX_PURPLE + "]" + CRYONIX_BLUE + " " + line, 0);
        break;
    default:
        break;
    }
}

void setup_console_window() {
    HWND console = GetConsoleWindow();
    if (console) {
        SetWindowPos(console, HWND_NOTOPMOST, 100, 100, 900, 600, SWP_SHOWWINDOW);
        LONG exStyle = GetWindowLong(console, GWL_EXSTYLE);
        exStyle |= WS_EX_NOACTIVATE | WS_EX_TRANSPARENT;
        SetWindowLong(console, GWL_EXSTYLE, exStyle);
        ShowWindow(console, SW_SHOWNOACTIVATE);
    }

    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD bufferSize = {120, 40};
    SetConsoleScreenBufferSize(hOut, bufferSize);
    SetConsoleTitleA("Cryonix-Client - [x64]");
}

void print_Cryonix_banner()
{
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    SetConsoleMode(hOut, dwMode);

    setup_console_window();

    std::cout << CRYONIX_PURPLE << BOLD << "\n";
    std::cout << "  ================================================\n";
    std::cout << "  ||                                                       ||\n";
    std::cout << "  ||              C R Y O N I X - V2                     ||\n";
    std::cout << "  ||                                                       ||\n";
    std::cout << "  ================================================\n";
    std::cout << RESET << CRYONIX_BLUE << BOLD << "\n        >> Cryonix-Client <<\n" << RESET;
    std::cout << CRYONIX_MAGENTA << "\n           Rewritten By Cryonix-Team !!\n" << RESET;
    std::cout << CRYONIX_PURPLE << BOLD << "\n        Join our community: " << CRYONIX_BLUE << UNDERLINE << "discord.gg/EecdaaUGy2" << RESET << "\n";
    std::cout << CRYONIX_PURPLE << "\n  [" << CRYONIX_BLUE << "SYSTEM" << CRYONIX_PURPLE << "]" << CRYONIX_MAGENTA << " Initializing CryonixV2..." << RESET << "\n";
    std::cout << CRYONIX_PURPLE << "  [" << CRYONIX_BLUE << "SYSTEM" << CRYONIX_PURPLE << "]" << CRYONIX_MAGENTA << " Loading features..." << RESET << "\n";
    std::cout << CRYONIX_PURPLE << "  [" << CRYONIX_BLUE << "SYSTEM" << CRYONIX_PURPLE << "]" << CRYONIX_MAGENTA << " Finished Loading!" << RESET << "\n";
}

template<typename T>
std::string toHexString(T value, bool prefix = false, bool uppercase = false)
{
    std::stringstream stream;
    if (uppercase)
        stream << std::uppercase;
    if (prefix)
        stream << "0x";
    stream << std::hex << value;
    return stream.str();
}