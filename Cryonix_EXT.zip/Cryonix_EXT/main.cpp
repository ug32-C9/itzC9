#include <iostream>
#include <thread>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <sys/stat.h>
#include <windows.h>

#include "Memory/MemoryManager.h"
#include "Utils/colors.h"
#include "Utils/console.h"
#include "Renderer/renderer.h"
#include "Hacks/misc.h"
#include "Caches/playercache.h"
#include "Caches/playerobjectscache.h"
#include "Caches/TPHandler.h"
#include "globals.h"

inline bool IsGameRunning(const wchar_t* title) {
    return FindWindowW(nullptr, title) != nullptr;
}

inline std::string GetExecutableDir() {
    char path[MAX_PATH]{};
    GetModuleFileNameA(nullptr, path, MAX_PATH);
    return std::filesystem::path(path).parent_path().string();
}

int main() {
    print_Cryonix_banner();

    log("Checking Roblox status...", 0);
    while (!IsGameRunning(L"Roblox")) {
        log("Roblox not running. Waiting for process...", 2);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    log("Roblox detected successfully!", 1);

    log("Connecting to Roblox process...", 3);
    if (!Memory->attachToProcess("RobloxPlayerBeta.exe")) {
        log("Failed to attach to Roblox process!", 2);
        log("Press any key to exit...", 0);
        std::cin.get();
        return EXIT_FAILURE;
    }

    DWORD procId = Memory->getProcessId("RobloxPlayerBeta.exe");
    uintptr_t baseAddr = Memory->getBaseAddress();

    if (!procId || !baseAddr) {
        log("Failed to retrieve Roblox process information!", 2);
        std::cin.get();
        return EXIT_FAILURE;
    }

    log("Cryonix-Client successfully injected!", 3);
    log("Process ID: " + std::to_string(procId), 3);
    log("Base Address: 0x" + toHexString(std::to_string(baseAddr), false, true), 3);

    Globals::executablePath = GetExecutableDir();
    Globals::configsPath = Globals::executablePath + "\\configs";

    std::string fontsPath = Globals::executablePath + "\\fonts";

    struct stat buffer;
    if (stat(fontsPath.c_str(), &buffer) != 0) {
        log("Fonts directory missing! Please ensure 'fonts' folder exists.", 2);
        std::cin.get();
        return EXIT_FAILURE;
    }

    if (stat(Globals::configsPath.c_str(), &buffer) != 0) {
        std::filesystem::create_directory(Globals::configsPath);
    }

    uintptr_t fakeDataModel = Memory->read<uintptr_t>(baseAddr + offsets::FakeDataModelPointer);
    RobloxInstance dataModel(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));

    while (dataModel.Name() != "Ugc") {
        fakeDataModel = Memory->read<uintptr_t>(baseAddr + offsets::FakeDataModelPointer);
        dataModel = RobloxInstance(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }

    Globals::Roblox::DataModel = dataModel;
    uintptr_t visualEngine = 0;

    while (!(visualEngine = Memory->read<uintptr_t>(baseAddr + offsets::VisualEnginePointer))) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }

    Globals::Roblox::VisualEngine = visualEngine;
    Globals::Roblox::Workspace = dataModel.FindFirstChildWhichIsA("Workspace");
    Globals::Roblox::Players = dataModel.FindFirstChildWhichIsA("Players");
    Globals::Roblox::Camera = Globals::Roblox::Workspace.FindFirstChildWhichIsA("Camera");
    Globals::Roblox::LocalPlayer = RobloxInstance(Memory->read<uintptr_t>(Globals::Roblox::Players.address + offsets::LocalPlayer));
    Globals::Roblox::lastPlaceID = Memory->read<int>(dataModel.address + offsets::PlaceId);

    log("Game DataModel: 0x" + toHexString(std::to_string(dataModel.address), false, true), 3);
    log("Rendering Engine: 0x" + toHexString(std::to_string(visualEngine), false, true), 3);
    log("Workspace: 0x" + toHexString(std::to_string(Globals::Roblox::Workspace.address), false, true), 3);
    log("Players: 0x" + toHexString(std::to_string(Globals::Roblox::Players.address), false, true), 3);
    log("Camera: 0x" + toHexString(std::to_string(Globals::Roblox::Camera.address), false, true), 3);
    log("Welcome, " + Globals::Roblox::LocalPlayer.Name() + "! Cryonix-Client is loaded.", 1);

    std::thread([] { ShowImGui(); }).detach();
    std::thread([] { CachePlayers(); }).detach();
    std::thread([] { CachePlayerObjects(); }).detach();
    std::thread([] { TPHandler(); }).detach();
    std::thread([] { MiscLoop(); }).detach();
    while (IsGameRunning(L"Roblox")) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    log("Roblox process ended. Shutting down Cryonix-Client...", 2);
    return EXIT_SUCCESS;
}