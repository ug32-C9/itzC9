# Saturn Api
 Here is the code of Saturn Api, open-source and free!
 Saturn Api is based on Xeno.

- UNC: 84%
- Level: 3
- Xeno.dll
- Only works on roblox web version

# Functions

SaturnApi.Api.Inject();

SaturnApi.Api.Execute();

SaturnApi.Api.IsRobloxOpen();

SaturnApi.Api.IsInjected();

SaturnApi.Api.KillRoblox();


# Credits

Xeno

https://discord.gg/xeno-now

https://www.xeno.onl
